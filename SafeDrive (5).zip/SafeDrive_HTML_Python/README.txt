SafeDrive — Python + HTML/CSS (no JavaScript)

Requirements: Python 3.10+ recommended

Run locally:
1. Extract this folder.
2. Open the folder in VS Code.
3. Open Terminal > New Terminal.
4. Run: python -m pip install -r requirements.txt
5. Run: python app.py
6. Open http://127.0.0.1:5000 in your browser.

This version uses Flask/Python to calculate the stopping distances and build the comparison table. The page uses HTML forms and CSS only; it contains no JavaScript. Submitting the form reloads the page with the results.

Model formulas:
- Reaction distance = speed (m/s) × reaction time
- Braking distance = speed² / (2 × friction coefficient × 9.81)
- Total stopping distance = reaction distance + braking distance

The friction coefficients are illustrative educational assumptions, not real-time road measurements. This model is not for real driving decisions.
