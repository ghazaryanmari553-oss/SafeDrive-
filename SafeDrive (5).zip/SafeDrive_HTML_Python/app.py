from flask import Flask, render_template, request
import math

app = Flask(__name__)
G = 9.81
ROADS = {
    "dry": ("Dry road", 0.75),
    "wet": ("Wet road", 0.45),
    "snow": ("Snow", 0.25),
    "ice": ("Ice", 0.10),
}


def stopping(speed_kmh, reaction_time, mu):
    speed_ms = speed_kmh / 3.6
    reaction = speed_ms * reaction_time
    braking = speed_ms ** 2 / (2 * mu * G)
    return {
        "reaction": reaction,
        "braking": braking,
        "total": reaction + braking,
    }


def max_safe_speed(distance, reaction_time, mu):
    if distance <= 0:
        return 0.0
    speed_ms = mu * G * (
        math.sqrt(reaction_time ** 2 + 2 * distance / (mu * G))
        - reaction_time
    )
    return max(0.0, speed_ms * 3.6)


@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    error = None
    values = {"speed": "60", "reaction_time": "1.2", "distance": "40", "road": "dry"}

    if request.method == "POST":
        values = {
            "speed": request.form.get("speed", "60"),
            "reaction_time": request.form.get("reaction_time", "1.2"),
            "distance": request.form.get("distance", "40"),
            "road": request.form.get("road", "dry"),
        }
        try:
            speed = float(values["speed"])
            reaction_time = float(values["reaction_time"])
            distance = float(values["distance"])
            road = values["road"]

            if road not in ROADS:
                raise ValueError("Choose a valid road condition.")
            if not all(math.isfinite(x) for x in (speed, reaction_time, distance)):
                raise ValueError("Enter valid numbers.")
            if not 0 <= speed <= 300:
                raise ValueError("Speed must be between 0 and 300 km/h.")
            if not 0 <= reaction_time <= 10:
                raise ValueError("Reaction time must be between 0 and 10 seconds.")
            if not 0 <= distance <= 10000:
                raise ValueError("Obstacle distance must be between 0 and 10,000 metres.")

            road_name, mu = ROADS[road]
            distances = stopping(speed, reaction_time, mu)
            graph_rows = []
            for graph_speed in range(0, 131, 10):
                row = {"speed": graph_speed}
                for key, (_, coefficient) in ROADS.items():
                    row[key] = stopping(graph_speed, reaction_time, coefficient)["total"]
                graph_rows.append(row)

            result = {
                "reaction": distances["reaction"],
                "braking": distances["braking"],
                "total": distances["total"],
                "safe_speed": max_safe_speed(distance, reaction_time, mu),
                "safe": distances["total"] <= distance,
                "road_name": road_name,
                "mu": mu,
                "graph_rows": graph_rows,
            }
        except (TypeError, ValueError) as exc:
            error = str(exc) or "Please enter valid numbers in every field."

    return render_template("index.html", result=result, error=error, values=values)


if __name__ == "__main__":
    app.run(debug=True)
